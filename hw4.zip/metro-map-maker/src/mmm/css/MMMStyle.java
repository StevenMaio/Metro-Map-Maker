/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mmm.css;

/**
 *
 * @author steve
 */
public class MMMStyle {
    public static final String STYLE_ITALICIZED_FONT = "-fx-font-style: italic";
    public static final String STYLE_BOLD_FONT = "-fx-font-weight: bold";
    public static final String STYLE_FONT_SIZE = "-fx-font-size:";
    public static final String STYLE_FONT_FAMILY = "-fx-font-family:";
    public static final String CLASS_MAX_PANE = "max_pane";
    public static final String CLASS_RENDER_CANVAS = "render_canvas";
    public static final String CLASS_BUTTON = "button";
    public static final String CLASS_EDIT_TOOLBAR = "edit_toolbar";
    public static final String CLASS_EDIT_TOOLBAR_ROW = "edit_toolbar_row";
    public static final String CLASS_EDIT_TOOLBAR_SUB_ROW = "edit_toolbar_sub_row";
    public static final String CLASS_COLOR_CHOOSER_PANE = "color_chooser_pane";
    public static final String CLASS_COLOR_CHOOSER_CONTROL = "color_chooser_control";
    public static final String CLASS_BORDERED_PANE = "bordered_pane";
    public static final String CLASS_COLOR_PICKER = "color_picker";
}
